SELECT 
    Region,
    Category,
    SUM(Revenue) AS Total_Revenue
FROM synthetic_ecommerce_data
GROUP BY Region, Category
ORDER BY Region, Total_Revenue DESC;
