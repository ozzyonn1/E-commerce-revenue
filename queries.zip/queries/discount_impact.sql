SELECT 
    Discount_Applied,
    COUNT(*) AS Transactions,
    ROUND(AVG(Revenue), 2) AS Avg_Revenue,
    ROUND(SUM(Revenue), 2) AS Total_Revenue
FROM synthetic_ecommerce_data
GROUP BY Discount_Applied
ORDER BY Discount_Applied;
