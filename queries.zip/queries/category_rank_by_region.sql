SELECT 
    Region,
    Category,
    SUM(Revenue) AS Total_Revenue,
    ROW_NUMBER() OVER (
        PARTITION BY Region 
        ORDER BY SUM(Revenue) DESC
    ) AS Category_Rank
FROM synthetic_ecommerce_data
GROUP BY Region, Category
ORDER BY Region, Category_Rank;
