SELECT 
    SUM(Ad_Spend) AS Total_Ad_Spend,
    SUM(Revenue) AS Total_Revenue,
    ROUND(SUM(Revenue) / NULLIF(SUM(Ad_Spend), 0), 2) AS ROI
FROM synthetic_ecommerce_data;
