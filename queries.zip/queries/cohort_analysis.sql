WITH first_purchase AS (
    SELECT 
        Customer_ID,
        MIN(DATE(Transaction_Date)) AS First_Purchase_Month
    FROM synthetic_ecommerce_data
    GROUP BY Customer_ID
),
transactions_with_cohort AS (
    SELECT 
        s.Customer_ID,
        DATE(s.Transaction_Date) AS Purchase_Date,
        STRFTIME('%Y-%m', s.Transaction_Date) AS Purchase_Month,
        STRFTIME('%Y-%m', f.First_Purchase_Month) AS Cohort_Month,
        JULIANDAY(s.Transaction_Date) - JULIANDAY(f.First_Purchase_Month) AS Cohort_Age_Days,
        s.Revenue
    FROM synthetic_ecommerce_data s
    JOIN first_purchase f ON s.Customer_ID = f.Customer_ID
)
SELECT 
    Cohort_Month,
    ROUND(Cohort_Age_Days / 30) AS Cohort_Month_Number,
    COUNT(DISTINCT Customer_ID) AS Active_Customers,
    ROUND(SUM(Revenue), 2) AS Total_Revenue
FROM transactions_with_cohort
GROUP BY Cohort_Month, Cohort_Month_Number
ORDER BY Cohort_Month, Cohort_Month_Number;
