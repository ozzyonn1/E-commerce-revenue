SELECT 
    Customer_ID,
    MAX(Transaction_Date) AS Last_Purchase,
    COUNT(*) AS Frequency,
    SUM(Revenue) AS Monetary_Value
FROM synthetic_ecommerce_data
GROUP BY Customer_ID
ORDER BY Monetary_Value DESC
LIMIT 10;
